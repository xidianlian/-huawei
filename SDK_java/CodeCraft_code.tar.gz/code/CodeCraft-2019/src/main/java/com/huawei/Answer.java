package com.huawei;

import java.util.ArrayList;

public class Answer {
	
	private int carId, realTime;
	
	private ArrayList<Integer> list;
	
	public Answer(int carId, int realTime, ArrayList<Integer> list) {
		this.carId = carId;
		this.realTime = realTime;
		this.list = list;
	}

	public int getCarId() {
		return carId;
	}

	public void setCarId(int carId) {
		this.carId = carId;
	}

	public int getRealTime() {
		return realTime;
	}

	public void setRealTime(int realTime) {
		this.realTime = realTime;
	}

	public ArrayList<Integer> getList() {
		return list;
	}

	public void setList(ArrayList<Integer> list) {
		this.list = list;
	}
	
}

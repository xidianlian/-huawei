package com.huawei;

import java.util.ArrayList;

public class Car implements Comparable<Car>{
	
	private int id, from, to, speed, planTime;
	
	private int minCost, realTime;
	
	private ArrayList<Integer> list;
	
	public Car(int id, int from, int to, int speed, int planTime) {
		this.id = id;
		this.from = from;
		this.to = to;
		this.speed = speed;
		this.planTime = planTime;
	}
	
	@Override
	public int compareTo(Car o) {
		return this.planTime - o.getPlanTime();
	}
	
	public int getRealTime() {
		return realTime;
	}


	public void setRealTime(int realTime) {
		this.realTime = realTime;
	}


	public ArrayList<Integer> getList() {
		return list;
	}


	public void setList(ArrayList<Integer> list) {
		this.list = list;
	}


	public int getMinCost() {
		return minCost;
	}


	public void setMinCost(int minCost) {
		this.minCost = minCost;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getFrom() {
		return from;
	}

	public void setFrom(int from) {
		this.from = from;
	}

	public int getTo() {
		return to;
	}

	public void setTo(int to) {
		this.to = to;
	}

	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getPlanTime() {
		return planTime;
	}
	public void setPlanTime(int planTime) {
		this.planTime = planTime;
	}


	@Override
	public String toString() {
		return "Car [id=" + id + ", from=" + from + ", to=" + to + ", speed=" + speed + ", planTime=" + planTime
				+ ", minCost=" + minCost + "]";
	}

}

package com.huawei;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;

import org.apache.log4j.Logger;

public class Main {
	
	 private static class Node implements Comparable<Node>{
    	int crossIndex; // cross
    	int len;
    	Node (int id, int len){
    		this.crossIndex = id;
    		this.len = len;
    	}
		@Override
		public int compareTo(Node o) {
			return this.len - o.len;
		}
    }
    private static final Logger logger = Logger.getLogger(Main.class);
    
    private static final int INF = 0x7f7f7f7f;
    
    private static HashMap<Integer, Integer> crossMp = new HashMap<Integer, Integer>();
    
    private static HashMap<Integer, Integer> roadsMp = new HashMap<Integer, Integer>();
    
    private static ArrayList<Integer> dij(Car car, ArrayList<Object> cross, ArrayList<Object> roads) {
    	ArrayList<Integer> ansList = new ArrayList<Integer>();
    	ArrayList<Integer> reverList = new ArrayList<Integer>();
     	int crossSize = cross.size();
    	int[] dis = new int[crossSize];
    	int[] vis = new int[crossSize];
    	int[] fa = new int[crossSize];
    	int[] answer = new int[crossSize];
    	for (int i = 0; i < crossSize; i++) {
    		dis[i] = INF;
    		vis[i] = 0;
    	}
    	LinkedList<Node> que = new LinkedList<Node>();
    	int index = crossMp.get(car.getFrom());
    	que.add(new Node(index, 0));
    	dis[index] = 0;
    	while (!que.isEmpty()) {
    		Node node = que.poll();
    		if (vis[node.crossIndex] == 1) {
    			continue;
    		}
    		vis[node.crossIndex] = 1;
    		Cross cro = (Cross)cross.get(node.crossIndex);
    		int[] roadIds = cro.getRoadIds();
    		for (int i = 0 ; i < roadIds.length; i++) {
    			int roadId = roadIds[i];
    			if (roadId == -1) {
    				continue;
    			}
    			Road road = (Road)roads.get(roadsMp.get(roadId));
    			int toIndex = -1;
    			if (road.getFrom() == cro.getId()) {
    				toIndex = crossMp.get(road.getTo());
    			} else if (road.getIsDuplex() == 1 && road.getTo() == cro.getId()){
    				toIndex = crossMp.get(road.getFrom());
    			}
    			if (toIndex == -1) {
    				continue;
    			}
    			int roadCost = 0;
    			if (road.getLength() % Math.min(car.getSpeed(), road.getSpeed()) == 0) {
    				roadCost = road.getLength() / Math.min(car.getSpeed(), road.getSpeed());
    			} else {
    				roadCost = (int)(road.getLength() / Math.min(car.getSpeed(), road.getSpeed()));
    				roadCost += 1;
    			}
    			
    			if (vis[toIndex] == 0 && dis[toIndex] > dis[node.crossIndex] + roadCost) {
    				dis[toIndex] = dis[node.crossIndex] + roadCost;
    				que.add(new Node(toIndex, dis[toIndex]));
    				fa[toIndex] = node.crossIndex;
    				answer[toIndex] = roadId;
    			}
    		}
    	}
    	int curIndex = crossMp.get(car.getTo());
    	int endIndex = crossMp.get(car.getFrom());
    	car.setMinCost(dis[curIndex]);
    	while (curIndex != endIndex) {	
    		reverList.add(answer[curIndex]);
    		curIndex = fa[curIndex];
    	}
    	for (int i = 0; i < reverList.size(); i++) {
    		ansList.add(reverList.get(reverList.size() - i - 1));
    	}
    	return ansList;
    }
    public static int random(int min, int max) {
    	return new Random().nextInt(max - min) + min;
    }
    public static void main(String[] args)
    {
        if (args.length != 4) {
            logger.error("please input args: inputFilePath, resultFilePath");
            return;
        }

        logger.info("Start...");

        String carPath = args[0];
        String roadPath = args[1];
        String crossPath = args[2];
        String answerPath = args[3];
        logger.info("carPath = " + carPath + " roadPath = " + roadPath + " crossPath = " + crossPath + " and answerPath = " + answerPath);
        // TODO:read input files
        logger.info("start read input files");
        ArrayList<Object> cars = new ArrayList<Object>();
        ArrayList<Object> cross = new ArrayList<Object>();
        ArrayList<Object> roads = new ArrayList<Object>();
        LinkedList<Car> que = new  LinkedList<Car>();
//        ArrayList<Answer> answers = new ArrayList<Answer>();
        try {
			FileOpt.readFile(carPath, cars, "Car");
			FileOpt.readFile(crossPath, cross, "Cross");
			FileOpt.readFile(roadPath, roads, "Road");
//			for (int i = 0 ; i < roads.size(); i++) {
//				Road road = (Road)roads.get(i);
//				logger.info(road.toString());
//			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // TODO: calc
        for (int i = 0; i < cross.size(); i++) {
        	Cross cro = (Cross)cross.get(i);
        	crossMp.put(cro.getId(), i);
        }
        for (int i = 0; i < roads.size(); i++) {
        	Road road = (Road)roads.get(i);
        	roadsMp.put(road.getId(), i);
        }
        for (int i = 0; i < cars.size(); i++) {
        	Car car = (Car)cars.get(i);
        	ArrayList<Integer> list = dij(car, cross, roads);
        	car.setList(list);
        	que.add(car);
        	//int randNum =  random(1, cars.size()) / 3;
        }
        cars = new ArrayList<Object>();
        while (!que.isEmpty()) {
        	cars.add(que.poll());
        }
        
        // TODO: write answer.txt
        logger.info("Start write output file");
        try {
			FileOpt.writeFile(answerPath, cars);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        logger.info("End...");
    }
}
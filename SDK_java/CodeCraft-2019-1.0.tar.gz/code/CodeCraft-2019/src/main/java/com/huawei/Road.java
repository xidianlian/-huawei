package com.huawei;

public class Road {
	
	private int id, length, speed, channel, from, to, isDuplex;
	
	public Road(int id, int length, int speed, int channel, int from, int to, int isDuplex) {
		this.id = id;
		this.length = length;
		this.speed = speed;
		this.channel = channel;
		this.from = from;
		this.to = to;
		this.isDuplex = isDuplex;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getChannel() {
		return channel;
	}
	public void setChannel(int channel) {
		this.channel = channel;
	}
	public int getFrom() {
		return from;
	}
	public void setFrom(int from) {
		this.from = from;
	}
	public int getTo() {
		return to;
	}
	public void setTo(int to) {
		this.to = to;
	}
	public int getIsDuplex() {
		return isDuplex;
	}
	public void setIsDuplex(int isDuplex) {
		this.isDuplex = isDuplex;
	}
	@Override
	public String toString() {
		return "Road [id=" + id + ", length=" + length + ", speed=" + speed + ", channel=" + channel + ", from=" + from
				+ ", to=" + to + ", isDuplex=" + isDuplex + "]";
	}
	
}

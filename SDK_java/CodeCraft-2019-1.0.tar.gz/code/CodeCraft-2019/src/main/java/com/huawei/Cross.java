package com.huawei;

import java.util.Arrays;

public class Cross {
	
	private int id;
	private int[] roadIds;
	public Cross(int id, int[] roadIds) {
		this.id = id;
		this.roadIds = roadIds;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int[] getRoadIds() {
		return roadIds;
	}
	public void setRoadIds(int[] roadIds) {
		this.roadIds = roadIds;
	}
	@Override
	public String toString() {
		return "Cross [id=" + id + ", roadIds=" + Arrays.toString(roadIds) + "]";
	}
	
	
}
